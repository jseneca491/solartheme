<style>
    /* .block-wrapper{
        display: flex;
    } */

    .item{
        outline: 1px solid red;
        float: left;
        width: 25%;
    }
</style>

<div class="block-wrapper">
    <div class="item" data-mh="blue"><img src="https://plchldr.co/i/120x240" alt="image ni"></div>
    <div class="item" data-mh="red"><img src="https://plchldr.co/i/120x600" alt="image ni"></div>
    <div class="item" data-mh="green"><img src="https://plchldr.co/i/125x125" alt="image ni"></div>
    <div class="item" data-mh="blue"><img src="https://plchldr.co/i/250x250" alt="image ni"></div>
    <div class="item" data-mh="yellow"><img src="https://plchldr.co/i/300x250" alt="image ni"></div>
    <div class="item" data-mh="green"><img src="https://plchldr.co/i/300x600" alt="image ni"></div>
    <div class="item" data-mh="purple"><img src="https://plchldr.co/i/336x280" alt="image ni"></div>
    <div class="item" data-mh="purple"><img src="https://plchldr.co/i/468x60" alt="image ni"></div>
    <div class="item" data-mh="yellow"><img src="https://plchldr.co/i/728x90" alt="image ni"></div>
    <div class="item" data-mh="red"><img src="https://plchldr.co/i/970x250" alt="image ni"></div>
    <div style="clear:both;"></div>
</div>