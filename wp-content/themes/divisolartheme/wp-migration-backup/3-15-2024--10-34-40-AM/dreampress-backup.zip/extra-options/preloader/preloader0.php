<div class="overlay-loader">
	<div class="loader">
		<div></div>
		<div></div>
		<div></div>
		<div></div>
		<div></div>
		<div></div>
		<div></div>
	</div>
</div>

<style type="text/css" >
.overlay-loader {
	display: block;
	margin: auto;
	width: 97px;
	height: 97px;
	position: relative;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
}
.loader {
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	margin: auto;
	width: 97px;
	height: 97px;
	animation-name: rotateAnim;
		-o-animation-name: rotateAnim;
		-ms-animation-name: rotateAnim;
		-webkit-animation-name: rotateAnim;
		-moz-animation-name: rotateAnim;
	animation-duration: 0.4s;
		-o-animation-duration: 0.4s;
		-ms-animation-duration: 0.4s;
		-webkit-animation-duration: 0.4s;
		-moz-animation-duration: 0.4s;
	animation-iteration-count: infinite;
		-o-animation-iteration-count: infinite;
		-ms-animation-iteration-count: infinite;
		-webkit-animation-iteration-count: infinite;
		-moz-animation-iteration-count: infinite;
	animation-timing-function: linear;
		-o-animation-timing-function: linear;
		-ms-animation-timing-function: linear;
		-webkit-animation-timing-function: linear;
		-moz-animation-timing-function: linear;
}
.loader div {
	width: 8px;
	height: 8px;
	border-radius: 50%;
	border: 1px solid <?php echo esc_attr(et_get_option('divi_DCT_preloader_color', '#fff'))?>;
	position: absolute;
	top: 2px;
	left: 0;
	right: 0;
	bottom: 0;
	margin: auto;
}
.loader div:nth-child(odd) {
	border-top: none;
	border-left: none;
}
.loader div:nth-child(even) {
	border-bottom: none;
	border-right: none;
}
.loader div:nth-child(2) {
	border-width: 2px;
	left: 0px;
	top: -4px;
	width: 12px;
	height: 12px;
}
.loader div:nth-child(3) {
	border-width: 2px;
	left: -1px;
	top: 3px;
	width: 18px;
	height: 18px;
}
.loader div:nth-child(4) {
	border-width: 3px;
	left: -1px;
	top: -4px;
	width: 23px;
	height: 23px;
}
.loader div:nth-child(5) {
	border-width: 3px;
	left: -1px;
	top: 4px;
	width: 31px;
	height: 31px;
}
.loader div:nth-child(6) {
	border-width: 4px;
	left: 0px;
	top: -4px;
	width: 39px;
	height: 39px;
}
.loader div:nth-child(7) {
	border-width: 4px;
	left: 0px;
	top: 6px;
	width: 49px;
	height: 49px;
}


@keyframes rotateAnim {
	from {
		transform: rotate(360deg);
	}
	to {
		transform: rotate(0deg);
	}
}

@-o-keyframes rotateAnim {
	from {
		-o-transform: rotate(360deg);
	}
	to {
		-o-transform: rotate(0deg);
	}
}

@-ms-keyframes rotateAnim {
	from {
		-ms-transform: rotate(360deg);
	}
	to {
		-ms-transform: rotate(0deg);
	}
}

@-webkit-keyframes rotateAnim {
	from {
		-webkit-transform: rotate(360deg);
	}
	to {
		-webkit-transform: rotate(0deg);
	}
}

@-moz-keyframes rotateAnim {
	from {
		-moz-transform: rotate(360deg);
	}
	to {
		-moz-transform: rotate(0deg);
	}
}
</style>