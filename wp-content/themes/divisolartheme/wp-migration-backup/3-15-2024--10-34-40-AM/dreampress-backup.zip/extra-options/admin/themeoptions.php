<?php
/**
* Theme Options Tab
*/
if (! defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<h2>DIVI Theme Options</h2> 
